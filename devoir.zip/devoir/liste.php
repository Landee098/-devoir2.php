<?php
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
    <header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.html">Gestion du Personnel de l'ESIH</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="formulaire.php">Enregistrement du personnel
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="liste.php">Liste des Personnes</a>
          </li>
          <li class="nav-item">
            <form action="" method="get">
            <input type="text" name="Position">
            <input type="submit" name="Recherche">
            </form>
           
          </li>
        </ul>
      </div>
    </div>
  </nav>
    </header>
    <br><br><br>

    <div style="height:auto;margin:auto;padding:auto; width:auto;border:1px solid #909c9d;">

            <table class="table">
                <thead class="thead-dark" >
                 <div class="card-header" style="text-align:center;font-size:28px;">
                 Information sur la personne recherchée
                 </div>  
                  <tr>
                    <th scope="col">Code</th>
                    <th scope="col">Nom</th>
                    <th scope="col">Prénom</th>
                    <th scope="col">Sexe</th>
                    <th scope="col">Date de Naissance</th>
                    <th scope="col">Nationalité</th>
                    <th scope="col">Téléphone</th>
                    <th scope="col">Email</th>
                    <th scope="col">Type de Personne</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                    if(isset($_SESSION['Personnel'])){
                        if(!empty($_SESSION['Personnel'])){
                        if(isset($_GET['Recherche'])){
                        $Position = (int)$_GET['Position'];
                        echo("<tr>");
                        echo('<td>'.$_SESSION['Personnel'][$Position]['code'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['nom'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['prenom'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['Sexe'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['Date_Naissance'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['Nationalité'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['Téléphone'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['Email'].'</td>');
                        echo('<td>'.$_SESSION['Personnel'][$Position]['Type'].'</td>');
                        echo("</tr>");
                        
                    //getCode($recherche);
                        }
                    }
                    }
                        
                ?>
                </tbody>
              </table>




            <div class="card">
                <div class="card-header" style="text-align:center;font-size:28px;">
                    Liste des personnes
                </div>
                <div class="card-body">
                <table class="table">
                <thead class="thead-dark">
                  <tr>
                  <th scope="col">Code</th>
                    <th scope="col">Nom</th>
                    <th scope="col">Prénom</th>
                    <th scope="col">Sexe</th>
                    <th scope="col">Date de Naissance</th>
                    <th scope="col">Nationalité</th>
                    <th scope="col">Téléphone</th>
                    <th scope="col">Email</th>
                    <th scope="col">Type de Personne</th>
                  </tr>
                </thead>
                <tbody>
                              <?php
                          if(isset($_SESSION['Personnel'])){
                              if(!empty($_SESSION['Personnel'])){
                          foreach($_SESSION['Personnel'] as $t){
                                  echo("
                                      <tr>
                                          <td>$t[code]</td>
                                          <td>$t[nom]</td>
                                          <td>$t[prenom]</td>
                                          <td>$t[Sexe]</td>
                                          <td>$t[Date_Naissance]</td>
                                          <td>$t[Nationalité]</td>
                                          <td>$t[Téléphone]</td>
                                          <td>$t[Email]</td>
                                          <td>$t[Type]</td>
                                      </tr>
                                  
                                  ");
                                  }
                              }
                          }
                      ?>
                </tbody>
              </table>

              
               
                </div>
        </div>
    </div>
<br>
    <footer class="py-5 bg-dark" style="margin-top:2px;">
    <div class="container">
      <p class="m-0 text-center text-white"> Ecole Superieure d'Infotronique d'Haiti(ESIH): 2eme Ruelle Nazon</p>
    </div>
    <!-- /.container -->
  </footer>
</body>
</html>