    <?php
    //session_start();
    ?>
    <?php
        if(isset($_GET['Deconnexion'])){
            session_destroy();
            header("location:return.php");
        }

    ?>

        <?php
            require_once 'ClassPersonnel.php';
            
            if(isset($_POST["Save"])){
                $code = $_POST['code'];
                $nom = $_POST['Nom'];
                $prenom = $_POST['Prenom'];
                $Sexe=$_POST['Sexe'];
                $Date_Naissance=$_POST['Date_Naissance'];
                $Nationalité=$_POST['Nationalité'];
                $Téléphone=$_POST['Téléphone'];
                $Email=$_POST['Email'];
                $Type= $_POST['Type'];
					$et = new Personnel($code,$nom,$prenom,$Sexe,$Date_Naissance,$Nationalité,$Téléphone,$Email,$Type);
					$t_et = [
						'code'=>$et->getCode(),
						'nom'=>$et->getNom(),
						'prenom'=>$et->getPrenom(),
						'Sexe'=>$et->getSexe(),
						'Date_Naissance'=>$et->getDate_Naissance(),
						'Nationalité'=>$et->getNationalité(),
						'Téléphone'=>$et->getTéléphone(),
						'Email'=>$et->getEmail(),
						'Type'=>$et->getType()
						];
                            
					$_SESSION['Personnel'][]=$t_et;
                
                                   
        }


    ?>


<?php
            if(isset($_SESSION['Personnel'])){
                if(!empty($_SESSION['Personnel'])){
            foreach($_SESSION['Personnel'] as $t){
                    echo("
                        <tr>
                            <td>$t[code]</td>
                            <td>$t[nom]</td>
                            <td>$t[prenom]</td>
                            <td>$t[Sexe]</td>
                            <td>$t[Date_Naissance]</td>
                            <td>$t[Nationalité]</td>
                            <td>$t[Téléphone]</td>
                            <td>$t[Email]</td>
                            <td>$t[Type]</td>
                        </tr>
                    
                    ");
                    }
                }
            }
        ?>


