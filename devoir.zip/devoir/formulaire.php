<?php session_start();

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
 <header style="border:1px solid ; height:auto;width:100%;color:white">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.html">Gestion du Personnel de l'ESIH</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="formulaire.php">Enregistrement du personnel
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="liste.php">Liste des Personnes</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="liste.php">Rechercher une personne</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</header> 
<div style="height:auto;margin:auto;padding:auto; width:700px;border:1px solid #253c3e;box-shadow:2px 2px 5px #909c9d;margin-top:70px;">  
        <div class="card">
                <div class="card-header" style="font-size:28px;text-align:center;">
                    Formulaire d'Enregistrement
                </div>
                <div class="card-body">
                <form action="formulaire.php" method="post">
                <label for="">Code</label>
                <input type="text" class="form-control" placeholder="Code" style="width:124px;" name="code">
                    <div class="row">
                        <div class="col">
                            <label for="">Nom</label>
                        <input type="text" class="form-control" placeholder="Nom" name="Nom">
                        <label for="">Prénom</label>
                        <input type="text" class="form-control" placeholder="Prénom" name="Prenom">
                        <label for="">Sexe</label><br>
                        <select class="custom-select mb-2 mr-sm-2 mb-sm-0" id="inlineFormCustomSelect"  name="Sexe" >
                            <option selected>Choose...</option>
                            <option value="Masculin">Masculin</option>
                            <option value="Féminin">Féminin</option>
                          
                        </select><br>
                        <label for="">Date de Naissance</label>
                        <input type="date" class="form-control" placeholder="Date de Naissance" name="Date_Naissance">
                        <label for="">Nationalité</label>
                        <input type="text" class="form-control" placeholder="Nationalité" name="Nationalité">
                      
                        <label for="">Téléphone</label>
                        <input type="text" class="form-control" placeholder="Téléphone" name="Téléphone">
                        <label for="">Email</label>
                        <input type="text" class="form-control" placeholder="Email" name="Email">
                        <label for="">Type de Personne</label><br>
                        <select class="custom-select mb-2 mr-sm-2 mb-sm-0" id="inlineFormCustomSelect"  name="Type">
                            <option selected>Choose...</option>
                            <option value="Etudiants">Etudiants</option>
                            <option value="Professeurs">Professeurs</option>
                            <option value="Personnelles Administratives">Personnelles Administratives</option>
                          
                        </select>
                        </div>
                    </div>
                    <button type="submit" name="Save" class="btn btn-dark" style="text-align:center;font-family:arial;margin-top:20px;float:right;">valider</button>
                </form>
                </div>
        </div>
  </div>
        <?php
            require_once 'ClassPersonnel.php';
            
            if(isset($_POST["Save"])){
                $code = $_POST['code'];
                $nom = $_POST['Nom'];
                $prenom = $_POST['Prenom'];
                $Sexe=$_POST['Sexe'];
                $Date_Naissance=$_POST['Date_Naissance'];
                $Nationalité=$_POST['Nationalité'];
                $Téléphone=$_POST['Téléphone'];
                $Email=$_POST['Email'];
                $Type= $_POST['Type'];
					$et = new Personnel($code,$nom,$prenom,$Sexe,$Date_Naissance,$Nationalité,$Téléphone,$Email,$Type);
					$t_et = [
						'code'=>$et->getCode(),
						'nom'=>$et->getNom(),
						'prenom'=>$et->getPrenom(),
						'Sexe'=>$et->getSexe(),
						'Date_Naissance'=>$et->getDate_Naissance(),
						'Nationalité'=>$et->getNationalité(),
						'Téléphone'=>$et->getTéléphone(),
						'Email'=>$et->getEmail(),
						'Type'=>$et->getType()
						];
                            
					$_SESSION['Personnel'][]=$t_et;
                
                                   
        }


    ?>
<br><br><br><br>
<footer class="py-5 bg-dark" style="margin-top:10px;">
    <div class="container">
      <p class="m-0 text-center text-white"> Ecole Superieure d'Infotronique d'Haiti(ESIH): 2eme Ruelle Nazon</p>
    </div>
    <!-- /.container -->
  </footer>
</body>

</html>